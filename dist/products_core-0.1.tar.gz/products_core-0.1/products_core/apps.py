from django.apps import AppConfig


class ProductsCore(AppConfig):
    name = 'products_core'
